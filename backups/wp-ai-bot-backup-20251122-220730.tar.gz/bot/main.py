import os
import time
import requests

# WordPress 設定
WP_BASE_URL = os.environ.get("WP_URL")
WP_USER = os.environ.get("WP_USER")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD")

# LLM 設定
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "http://llama:8080")
MODEL_FILE = os.environ.get("MODEL_FILE", "/models/model.gguf")

# WP の投稿エンドポイント
WP_POSTS_URL = WP_BASE_URL.rstrip("/") + "/wp-json/wp/v2/posts"


def call_llm(prompt, max_tokens=300, max_retries=5, wait_sec=5):
    """
    LLM にプロンプトを投げて本文をもらう。
    max_tokens はサーバー負荷を考えて 300 に抑える。
    """
    url = LLM_BASE_URL.rstrip("/") + "/v1/completions"
    payload = {
        "model": MODEL_FILE,
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": 0.6,
        "top_p": 0.9,
        "stop": ["#", "【", "■"],  # 変な見出しを防止
    }

    for i in range(max_retries):
        print(f"LLM リクエスト {i+1}/{max_retries}")
        try:
            resp = requests.post(url, json=payload, timeout=120)
        except requests.exceptions.ReadTimeout:
            print("LLM 読み取りタイムアウト。再試行します。")
            time.sleep(wait_sec)
            continue

        if resp.status_code == 503:
            print("LLM 503：モデル読み込み中。少し待って再試行します。")
            time.sleep(wait_sec)
            continue

        if resp.status_code != 200:
            print("LLM HTTP エラー:", resp.status_code, resp.text[:200])
            raise RuntimeError("LLM HTTP error")

        text = resp.json()["choices"][0]["text"]
        return text.strip()

    raise RuntimeError("LLM リトライ上限に達しました")


def generate_article(theme: str):
    """
    テーマを渡して、(タイトル, 本文) を返す。
    タイトル = テーマ、本文 = LLM の出力。
    """
    prompt = f"""
あなたは優秀な日本語ライターです。
以下のテーマについて、約800〜1000文字の自然な記事を書いてください。

テーマ: {theme}

【出力条件】
- 導入 → 背景 → 具体例 → まとめ の構成にする
- 見出しはつけない（# や ■ などは使わない）
- 箇条書き禁止
- 同じ文やフレーズを何度も繰り返さない
- この指示文や「テーマ:」の行は記事に含めない
- 記事本文だけを出力する
"""
    body = call_llm(prompt)
    title = theme
    return title, body


def post_to_wordpress(title, content):
    if not WP_BASE_URL:
        print("WP_URL が設定されていません（.env を確認してください）")
        return

    data = {
        "title": title,
        "content": content,
        "status": "draft",  # 下書きで保存
    }

    resp = requests.post(
        WP_POSTS_URL,
        json=data,
        auth=(WP_USER, WP_APP_PASSWORD),
        timeout=60,
    )

    print("WP status:", resp.status_code)
    print("WP response (head):", resp.text[:300])


def main():
    theme = os.environ.get("TOPIC", "民泊とは何か？")

    try:
        title, content = generate_article(theme)
    except Exception as e:
        print("LLM 呼び出しに失敗:", e)
        return

    print("=== 投稿タイトル ===")
    print(title)
    print("=== 本文 先頭200文字 ===")
    print(content[:200])
    print("======================")

    post_to_wordpress(title, content)


if __name__ == "__main__":
    main()
