import os
import time
from typing import Optional

import requests

from templates import get_static_templates_text
from local_news import LocalNewsFetcher
from past_titles_db import (
    init_db,
    add_title,
    find_similar_titles,
    fetch_recent_titles,
)

# ==== 環境変数 ====

WP_BASE_URL = os.environ.get("WP_URL")
WP_USER = os.environ.get("WP_USER")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD")

LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "http://llama:8080")
MODEL_FILE = os.environ.get("MODEL_FILE", "/models/model.gguf")

TOPIC = os.environ.get("TOPIC", "").strip()  # 手動固定テーマ（ふだんは空を想定）

WP_POST_STATUS = os.environ.get("WP_POST_STATUS", "draft")  # publish にすれば即公開

if not WP_BASE_URL:
    raise RuntimeError("WP_URL is not set in environment")

WP_POSTS_URL = WP_BASE_URL.rstrip("/") + "/wp-json/wp/v2/posts"
LLM_COMPLETIONS_URL = LLM_BASE_URL.rstrip("/") + "/v1/completions"


# ==== LLM呼び出し ====

def call_llm(
    prompt: str,
    max_tokens: int = 1024,
    temperature: float = 0.7,
    stop=None,
) -> str:
    """
    llama.cpp (/v1/completions) を叩く汎用関数。
    """
    if stop is None:
        stop = ["</s>"]

    payload = {
        "model": MODEL_FILE,
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stop": stop,
    }

    last_error: Optional[Exception] = None
    for i in range(3):
        try:
            resp = requests.post(
                LLM_COMPLETIONS_URL,
                json=payload,
                timeout=120,
            )
            resp.raise_for_status()
            data = resp.json()

            if "choices" in data and data["choices"]:
                text = data["choices"][0].get("text", "")
            else:
                text = data.get("text", "")

            return text.strip()
        except Exception as e:
            last_error = e
            print(f"[call_llm] error ({i+1}/3): {e}")
            time.sleep(2)

    raise RuntimeError(f"LLM request failed after retries: {last_error}")


# ==== テーマ生成エージェント ====

def generate_theme(
    local_news_context: str,
    static_templates_text: str,
) -> str:
    """
    幡ヶ谷 × 民泊 × 集客 に特化したテーマを1つ自動で生成する。
    過去タイトルと類似している場合は複数回リトライする。
    """

    recent = fetch_recent_titles()
    past_titles_text = "\n".join(f"- {title}" for _, title in recent)

    base_prompt = f"""
あなたは「渋谷区・幡ヶ谷エリア」専門の民泊集客コンサルタント兼
ローカルメディア編集長です。

目的：
- 幡ヶ谷エリアの民泊に泊まりに来るお客様を集客するための
  ブログ記事テーマ（タイトル）を1つだけ考えること

条件：
- 毎日1本ずつ、数年にわたり投稿し続ける想定
- 同じ内容・似た内容にならないこと（少なくとも1万通り以上を意識）
- 必ず「幡ヶ谷」または「渋谷区」を含める
- 民泊・宿泊に関係する内容にする（「民泊」か「宿泊」などが文脈に含まれる）
- 抽象的な「〜とは？」だけのタイトルは禁止
- 旅行者や民泊ゲストが検索しそうなキーワードを含める
- 不安解消・具体的なイメージ・街の魅力・アクセス・グルメなど、
  予約や問い合わせにつながる角度を必ず入れる
- 34〜42文字程度で日本語タイトルを1つだけ出力する
- 箇条書き・番号・コメントは禁止。タイトル文字列1行のみ。

今日のローカル情報（自動取得したもの）：
{local_news_context}

幡ヶ谷 × 民泊のテーマの型（自動生成された多数のパターンの一例）：
{static_templates_text}

過去に投稿済みのタイトル一覧（一部）：
{past_titles_text}

上記をすべて踏まえ、まだ扱っていない新しい視点・組み合わせで
幡ヶ谷エリアの民泊集客に役立つブログ記事タイトルを
1つだけ提案してください。
    """.strip()

    last_candidate = None

    for attempt in range(5):
        if attempt == 0:
            prompt = base_prompt
        else:
            prompt = base_prompt + f"""

前回の候補タイトル：
- {last_candidate}

これは既存のタイトルと似ている、または内容が近すぎると判断されたため、
これとは異なる全く新しい切り口のタイトルを
1つだけ再提案してください。
            """.strip()

        raw = call_llm(prompt, max_tokens=128, temperature=0.7)
        first_line = raw.splitlines()[0].strip()

        # 先頭の番号や記号を削る
        candidate = first_line.lstrip("0123456789. 　-・「」『』[]【】")

        # 幡ヶ谷 / 渋谷区 / 民泊or宿泊 が抜けていたときの最低限の自動補正
        if "幡ヶ谷" not in candidate and "渋谷区" not in candidate:
            candidate = f"幡ヶ谷で楽しむ {candidate}"
        if "民泊" not in candidate and "宿泊" not in candidate:
            candidate = candidate + " 民泊宿泊ガイド"

        similar = find_similar_titles(candidate)
        if not similar:
            return candidate

        print(f"[THEME] similar detected (attempt {attempt+1}): {candidate}")
        print(f"[THEME] similar to: {similar[:3]}")
        last_candidate = candidate

    # 5回試しても類似してしまう場合は最後の案を採用（完全自動運用前提）
    return last_candidate or "幡ヶ谷民泊の集客ブログタイトル自動生成"


# ==== 記事本文エージェント ====

def generate_article(theme: str) -> tuple[str, str]:
    """
    テーマ（タイトル）から本文を生成する。
    """
    prompt = f"""
あなたは民泊運営と旅行者ニーズに精通した日本語ライターです。

次のテーマで、渋谷区幡ヶ谷エリアの民泊に泊まりたい人向けに
ブログ記事の本文を書いてください。

テーマ:「{theme}」

▼読者像
- 東京旅行を検討している国内外の旅行者
- 渋谷や新宿に行きたいが、どこに泊まるか悩んでいる人
- 幡ヶ谷のことをあまり知らない人

▼執筆条件
- です・ます調で、親しみやすく丁寧な文体
- 構成は「導入 → 見出し付きの本文（3〜4セクション）→ まとめ」
- 見出しには Markdown 形式で「## 見出しタイトル」を使う
- 文字数はおよそ 1200〜1600 文字
- 幡ヶ谷エリアの魅力・アクセス・周辺の飲食店や観光などを
  できるだけ具体的にイメージしやすく書く
- 不安解消（治安・移動・買い物・言葉の問題など）につながる情報を含める
- 特定の物件名や広告的な表現は避け、一般的な民泊を想定して書く

▼出力形式
- 出力は本文のみ（タイトル行は書かない）
- コードブロックや余計な説明文は付けない
    """.strip()

    body = call_llm(prompt, max_tokens=1500, temperature=0.8)
    return theme, body


# ==== WordPress 投稿 ====

def post_to_wordpress(title: str, content: str, status: str = "draft"):
    data = {
        "title": title,
        "content": content,
        "status": status,
    }
    print(f"[WP] Posting: title={title!r}, status={status}")
    resp = requests.post(
        WP_POSTS_URL,
        json=data,
        auth=(WP_USER, WP_APP_PASSWORD),
        timeout=120,
    )
    if not resp.ok:
        print("[WP] Error:", resp.status_code, resp.text)
        resp.raise_for_status()
    else:
        try:
            link = resp.json().get("link")
        except Exception:
            link = None
        print("[WP] Success:", resp.status_code, link)


# ==== 1回分のフロー ====

def run_once():
    """
    1回の実行で：
    - DB初期化
    - テーマ生成
    - 本文生成
    - WP投稿
    - タイトルをDBに保存
    までを自動で行う。
    """
    init_db()

    # 1. テーマ決定
    if TOPIC:
        theme = TOPIC
        print(f"[THEME] Using fixed TOPIC from .env: {theme}")
    else:
        fetcher = LocalNewsFetcher()
        local_news_context = fetcher.build_local_news_context()
        static_templates_text = get_static_templates_text()
        theme = generate_theme(local_news_context, static_templates_text)
        print(f"[THEME] Generated theme: {theme}")

    # 2. 本文生成
    title, content = generate_article(theme)
    print(f"[ARTICLE] Generated article length: {len(content)} characters")

    # 3. WordPress に投稿
    post_to_wordpress(title, content, status=WP_POST_STATUS)

    # 4. タイトルをDBに保存
    add_title(title)
    print("[DB] Title stored")


def main():
    run_once()


if __name__ == "__main__":
    main()
