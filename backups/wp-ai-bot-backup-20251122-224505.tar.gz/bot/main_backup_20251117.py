import os
import time
import requests
from datetime import datetime

WP_URL = os.environ.get("WP_URL")
WP_USER = os.environ.get("WP_USER")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD")
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "http://llama:8080")
TOPIC = os.environ.get("TOPIC", "今日の話題")


def call_llm(prompt, max_retries=5, wait_sec=10):
    url = LLM_BASE_URL.rstrip("/") + "/v1/completions"
    payload = {
        "model": "/models/model.gguf",
        "prompt": prompt,
        "temperature": 0.5,
        "top_p": 0.9,
        "max_tokens": 200,
        "repeat_penalty": 1.25,
        "repeat_last_n": 256
    }

    for i in range(max_retries):
        print(f"LLM リクエスト {i+1}/{max_retries}")
        try:
            resp = requests.post(url, json=payload, timeout=240)

            # 503: モデル読み込み中
            if resp.status_code == 503:
                print("LLM側がロード中。10秒待ってリトライします。")
                time.sleep(wait_sec)
                continue

            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["text"]

        except requests.exceptions.ReadTimeout:
            print("LLM 読み取りタイムアウト。待って再試行します。")
            time.sleep(wait_sec)
        except Exception as e:
            print("LLM 呼び出し例外:", e)
            time.sleep(wait_sec)

    return None  # フォールバック用


def generate_article():
    """テーマに基づき約1000文字の記事を生成する"""
    prompt = f"""以下のテーマについて、日本語で読みやすく1000文字程度の記事を書いてください。
テーマ: {TOPIC}

・導入
・背景説明
・具体例
・まとめ

※ 同じ文章を繰り返さないこと。
※ 箇条書き形式ではなく、自然な文章で書いてください。

の構成で、専門的すぎず一般向けに書いてください。
"""

    text = call_llm(prompt)
    if not text:
        text = "（LLM生成に失敗しました。後ほど再試行してください。）"

    return text


def post_to_wordpress(title, content):
    data = {
        "title": title,
        "content": content,
        "status": "draft"
    }

    resp = requests.post(
        WP_URL,
        json=data,
        auth=(WP_USER, WP_APP_PASSWORD)
    )

    print("WP status:", resp.status_code)
    print("WP response:", resp.text)


def main():
    title = f"{TOPIC}"
    content = generate_article()
    post_to_wordpress(title, content)


if __name__ == "__main__":
    main()

